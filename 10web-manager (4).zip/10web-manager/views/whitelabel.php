<div class="tw_wl_banner">
    <div>
        <img src="<?php echo TENWEB_URL ?>/assets/images/whitelabel/exclamation.png" />
        <div>
            <h1><?php echo $plugin_title ?> settings are managed by your hosting service.</h1>
            <p>Please contact support with any questions.</p>
        </div>
    </div>
</div>